package com.poliban.asus.pertemuan52;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Input_Nama extends AppCompatActivity {
private TextView tampil;
private Button ok;
private EditText in;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input__nama);
        ok=(Button)findViewById(R.id.btninput);
        tampil=(TextView)findViewById(R.id.tampil);
        in=(EditText) findViewById(R.id.input);
    }
    public void TampilNama(View v){
        tampil.setText("nama"+in.getText());
    }
}
