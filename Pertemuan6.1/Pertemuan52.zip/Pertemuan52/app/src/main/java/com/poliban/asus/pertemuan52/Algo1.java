package com.poliban.asus.pertemuan52;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Algo1 extends AppCompatActivity {

    private TextView tampil;
    private EditText input;
    private Button ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_algo1);
        input=(EditText) findViewById(R.id.inputangka);
        ok=(Button)findViewById(R.id.cari);
        tampil=(TextView)findViewById(R.id.Tampilkan);

    }
    public void Hasil(View v){
        int x=1,y=0,a;
        a= Integer.parseInt(String.valueOf(input.getText()));
        y=x*x;
        while (y!=a){
            x+=1;
            y=x*x;
        }
        tampil.setText("Akarnya adalah "+ x);
    }
}
