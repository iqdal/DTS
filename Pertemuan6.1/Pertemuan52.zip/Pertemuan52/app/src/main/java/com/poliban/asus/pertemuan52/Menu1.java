package com.poliban.asus.pertemuan52;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu1 extends AppCompatActivity {
    Button BtnOk,btnn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);
        BtnOk=(Button)findViewById(R.id.Btn1);
        btnn2=(Button)findViewById(R.id.button);
    }
    public void Rubahwarna(View v){
        BtnOk.setBackgroundColor(Color.RED);
    }
    public void WarnaHijau(View v){
        btnn2.setBackgroundColor(Color.GREEN);
    }
    }

