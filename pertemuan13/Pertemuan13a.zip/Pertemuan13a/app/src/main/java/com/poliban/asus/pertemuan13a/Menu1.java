package com.poliban.asus.pertemuan13a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu1 extends AppCompatActivity {
    private EditText nim,nama;
    private TextView hasil;
    private Button ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);
        nim=findViewById(R.id.nim);
        nama=findViewById(R.id.nama);
        hasil=findViewById(R.id.hasil);
        ok=findViewById(R.id.button2);
    }
    public void tampil(View v){
        hasil.setText(nim.getText()+"\n"+nama.getText());
    }
}
